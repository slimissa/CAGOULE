CAGOULE v3.1.0
Cryptographie Algébrique Géométrique par Ondes et Logique Entrelacée

Version License: MIT Python Platform C Tests Python Tests Security

⚠️ Research-grade software. CAGOULE is not a production replacement for AES-GCM or ChaCha20-Poly1305. The algebraic layer has no published IND-CPA proof — this is documented and tracked. The outer ChaCha20-Poly1305 AEAD (the default mode) provides standard IND-CCA2 security regardless of the algebraic layer's status. See SECURITY.md.

What is CAGOULE?
CAGOULE is a hybrid symmetric encryption research project combining battle-tested standard primitives with a novel algebraic construction built for study, experimentation, and eventual formal analysis.

Standard layer (always active, proven):

Argon2id — memory-hard password-based key derivation
HKDF-SHA256 — key expansion and domain separation
ChaCha20-Poly1305 — authenticated encryption (default mode)
Algebraic layer (the research contribution):

Dynamic Mersenne-64 prime pool — 8 primes, password-derived selection
Vandermonde / Cauchy MDS diffusion matrix — 16×16 over Z/pZ
2-round Feistel S-box — round keys derived from ζ(2n) Fourier coefficients
CTR mode — full AVX2 4x pipeline, ARM NEON backend (v3.1.0)
The algebraic layer applies a password-specific permutation to each plaintext block before ChaCha20-Poly1305 encrypts the result. Even if the algebraic layer were broken, ChaCha20-Poly1305 provides standard confidentiality and integrity.

Why build this?

AES and ChaCha20 are the right choice for production encryption. CAGOULE exists for a different reason: its algebraic structure (x^d mod p, Vandermonde matrices, prime-field arithmetic) is native to the same mathematical setting as ZK-SNARKs and algebraic cryptanalysis tools. This makes it useful as:

A research platform for studying algebraic cipher design
A testbed for neural cryptanalysis experiments (Phase 3 of the IND-CPA roadmap)
A prototype for ZK-circuit-friendly authenticated encryption
Architecture
Password ──► Argon2id (memory-hard) ──► k_master (32B)
                                              │
                              ┌───────────────┴────────────────────┐
                              │                                    │
                         HKDF-SHA256                          HKDF-SHA256
                              │                                    │
                    ┌─────────▼─────────┐                         │
                    │  Algebraic layer  │                     k_stream (32B)
                    │                   │                          │
                    │  Prime p (Z/pZ)   │                          ▼
                    │  Vandermonde MDS  │              ChaCha20-Poly1305 AEAD
                    │  Feistel S-box    │              (confidentiality +
                    │  ζ(2n) round keys │               integrity, proven)
                    │  CTR streaming    │                          │
                    └────────┬──────────┘                         │
                             │ ct_alg                             │
                             └──────────────┬─────────────────────┘
                                            │
                                       CGL1 v0x02
                         MAGIC | VERSION | SALT | NONCE | CT_AEAD | TAG
                          (4)      (1)     (32)   (12)     (n)      (16)
                                    65-byte overhead
Experimental mode (v0x03 — research only)
v3.1.0 introduces a second pipeline where ChaCha20 is removed and Poly1305 authenticates the algebraic ciphertext directly. This mode:

Is opt-in only — requires both allow_experimental=True and CAGOULE_EXPERIMENTAL_NO_AEAD=1 in the environment
Has no IND-CPA guarantee — confidentiality depends entirely on the algebraic layer, which is unproven
Exists to benchmark and analyze the algebraic layer in isolation
Will not become the default until a formal IND-CPA argument is published
CGL1 v0x03:  MAGIC | VERSION | SALT | CT_ALG | TAG
              (4)     (1)      (32)    (n)      (16)
               53-byte overhead (no NONCE field — no ChaCha20)
What's New in v3.1.0
Feature 1 — Experimental mode without ChaCha20 (v0x03)
cipher_ctr_raw.py and cagoule_encrypt_with_handle_raw() implement the Poly1305-only pipeline behind a double opt-in gate. The format wire overhead drops from 65 to 53 bytes. Not suitable for production data.

Feature 2 — Unified C API (cagoule_api.c)
A new C layer wraps the full pipeline (KDF → matrix → S-box → CTR → AEAD → CGL1 header) behind a single call. **Correction from earlier drafts of this document: this does not eliminate a "~28% ctypes overhead."** Direct measurement of the per-primitive Python path shows ctypes marshaling overhead is under 1% of per-message cost — it was never the bottleneck the earlier framing implied. The real value of this API is elsewhere:

- **Single call, no per-primitive Python↔C round trips** — one function does KDF, matrix, S-box, CTR, AEAD, and header assembly, rather than the caller orchestrating each stage separately.
- **Caller-owned output buffer** — `memset(out, 0, out_len)` after use is a reliable zeroization path, sidestepping the CPython `bytes` immutability limitation present in the pure-Python layer.
- **MAC-first guarantee** — the tag is always verified in an internal buffer before any plaintext is written to `out`. No unauthenticated plaintext is ever released to the caller.

If you're choosing between this API and the per-primitive Python path purely for throughput, measure your own workload first — the gap is smaller than earlier documentation suggested.

/* Single-message, full KDF per call */
int cagoule_encrypt_v3(password, pwd_len, plaintext, pt_len, out, out_len);
int cagoule_decrypt_v3(password, pwd_len, ciphertext, ct_len, out, out_len);

/* Bulk: amortize Argon2id across N messages */
CagouleKeyHandle *h = cagoule_derive_key(password, pwd_len, salt, salt_len);
int cagoule_encrypt_with_handle(h, plaintext, pt_len, out, out_len);
int cagoule_decrypt_with_handle(h, ciphertext, ct_len, out, out_len);
void cagoule_key_handle_free(h);

Feature 3 — ARM NEON backend
cagoule_matrix_neon.c implements the 16×16 Vandermonde matrix multiply using 128-bit NEON intrinsics (2 lanes). ARM's native unsigned comparison eliminates the MSB-flip workaround required by AVX2's signed-only _mm256_cmpgt_epi64.

Targets: Apple Silicon (M1–M4), AWS Graviton 2/3, Raspberry Pi 4/5. Compiled automatically when __ARM_NEON is defined. Same dispatch mechanism as the existing AVX2 path — no API changes.

Feature 4 — Streaming API with per-chunk MAC (cagoule_stream.c)
Large files are processed in configurable chunks (default 64 KB). Each chunk receives an independent Poly1305 tag, keyed via HKDF(k_master, "CAGOULE_CTR_V31" || chunk_index, 8). No plaintext chunk is released to the caller before its tag is verified.

CagouleStreamCtx *ctx = cagoule_stream_init(password, pwd_len, chunk_size, 0);
int cagoule_stream_update(ctx, chunk_in, chunk_len, chunk_out, out_len);
// out = ct_chunk ‖ tag (chunk_len + 16 bytes)
int cagoule_stream_final(ctx, out_final, final_len);
void cagoule_stream_free(ctx);
Per-chunk overhead: 16 bytes (Poly1305 tag). At 64 KB chunks this is 0.025% overhead, independent of file size.

Security fixes carried from v3.0.1
v3.1.0 carries all 10 fixes from v3.0.1. The most critical:

Fix	Description
Bug 2 — CTR IV	IV = HKDF(k_master, "CAGOULE_CTR_V31" + nonce, 8) — bound to per-message nonce, not k_master alone
Bug 6 — Python S-box	Full Feistel port in Python, bit-exact vs C across all 8 production primes
Bug 3 — pickle	CagouleParams.__reduce__ raises TypeError — k_master no longer exposed via IPC
Batch-1 implementation fixes (v3.1.0 analysis pass)
27 issues fixed across 9 source files. Key items:

cagoule_api.c: nonce generated before derive_iv, correct experimental gate error code, output zeroized on CTR error
cagoule_ctr.c: union type-pun for all (int64_t)p casts — UBSan clean
cagoule_sbox.c: _invmod_generic uses __int128 — correct for Mersenne-64 inputs
cagoule_stream.c: allow_experimental falls through to safe default instead of returning NULL
_buffer_pool.py: reuse-path zeroize, re-entrancy guard, specific exception handling in _zeroize_buf
cipher_ctr.py: size assertion before memmove, per-element type check in bulk
decipher_ctr.py: per-element error collection in decrypt_bulk_ctr (no abort on first failure)
params.py: fast_mode applied to Argon2id path, delta constrained to [1, p-1]
Performance
Measured on x86-64 Linux, single core, -O3 -march=native. **Updated post-audit** (previous figures in this section predated a root-cause fix to the AVX2 CTR matrix multiply and a benchmark-methodology correction — see notes below the table):

Operation	Throughput	Notes
CTR encrypt 1 MB (C, v0x02, production config)	50.5 MB/s	Z-Domain Shifting active, matching real usage
CTR encrypt 1 MB (C, v0x02, best case)	52.8 MB/s	Same build, favorable run — see variance note below
CTR encrypt 1 MB (Python e2e)	26–32 MB/s	ctypes overhead confirmed <1%, not ~28% (see Feature 2 correction above)
CTR encrypt 1 MB (C, v0x03 experimental)	~35 MB/s	No ChaCha20 — research only; not re-measured this pass
CBC encrypt 1 MB (C)	10.6 MB/s	Legacy path — not touched by this pass's fixes
S-box forward (AVX2, 65K blocks)	120 MB/s	4-lane vectorized
S-box forward (scalar, 65K blocks)	86 MB/s	Auto-vectorized by GCC
mulmod64 (scalar)	5.9 ns/op	~170M ops/s
ARM NEON (Apple M2, estimated)	>20 MB/s	2-lane, no MSB-flip penalty

Where the time goes (CTR encrypt, per 16-byte block) — corrected:

Matrix multiply (16×16 mulmod64)  ≈ 44%
S-box (16 Feistel passes)         ≈ 43%
Round key addition + Z-shift      ≈  8%
Counter block + XOR               ≈  5%

The earlier "≈70% matrix / ≈20% S-box" breakdown in prior documentation was wrong — measured directly from the code's own per-stage profiler, matrix and S-box cost are roughly equal, not matrix-dominant. This matters because it means S-box optimization is a legitimate target for future work, not "wasted effort" as earlier internal planning documents assumed.

**AVX2 matrix dispatch regression: fixed.** Earlier documentation in this section described AVX2 matrix multiply as sometimes slower than scalar due to "dispatch overhead." The actual root cause was different and has been fixed: the AVX2 matrix multiply was performing a full modular reduction after every multiply-accumulate (256 reductions per 16×16 block) instead of accumulating raw products and reducing once (16 reductions per block) — the same deferred-reduction strategy the scalar path already used. A new CTR-only function (`cagoule_matrix_mul_avx2_lazy`) applies this fix; CBC continues using the original, unmodified function, since the byte-range-input precondition the fix relies on does not hold for CBC's full-field-element chaining. Verified via 1.6M+ adversarial fuzz trials against the always-correct reference implementation (0 mismatches) in addition to the full regression suite. AVX2 is no longer slower than scalar on tested hardware.

**Methodology note on the numbers above:** these were measured on a single-vCPU virtualized environment with no CPU pinning or governor control — repeated runs of the identical build have varied by up to 2× across measurement sessions in this environment. Treat the table as directionally accurate (production config < best case; Python e2e roughly half of C throughput) rather than as precise, reproducible absolute figures. Re-measure on dedicated, pinned hardware before citing a specific number externally.

For context: AES-256-GCM reaches ~4 GB/s with AES-NI. ChaCha20-Poly1305 reaches ~500 MB/s in software. CAGOULE is not competing on throughput — it is built for algebraic flexibility and ZK-circuit compatibility, not raw speed.

Quick Start
Build the C backend
# Install dependencies (Ubuntu/Debian)
sudo apt-get install gcc libssl-dev libargon2-dev

# Build
cd cagoule/c
make clean && make all
# libcagoule.so → cagoule/c/ and cagoule/

# Verify
make tests
Install Python dependencies
Requires Python 3.12+ (see `pyproject.toml`'s `requires-python`).
pip install cryptography argon2-cffi
pip install mpmath  # optional: for cross-backend ζ(2n) verification tests
Basic Python usage
from cagoule import encrypt, decrypt

# Encrypt — CTR mode, CGL1 v0x02 (ChaCha20-Poly1305 + algebraic layer)
ciphertext = encrypt(b"secret message", b"my password")

# Decrypt — auto-dispatches v0x01 CBC / v0x02 CTR from header
plaintext = decrypt(ciphertext, b"my password")
assert plaintext == b"secret message"
KDF amortization (bulk encryption)
from cagoule.params import CagouleParams
from cagoule.cipher_ctr import encrypt_ctr
from cagoule.decipher_ctr import decrypt_ctr

# Derive once, encrypt many — Argon2id runs once, not per-message
params = CagouleParams.derive(b"my password")
try:
    ct1 = encrypt_ctr(b"message one", b"my password", params=params)
    ct2 = encrypt_ctr(b"message two", b"my password", params=params)

    # Each ciphertext is independently decryptable cross-session:
    # delete params, re-derive from (password, header_salt) — works correctly
    del params
    pt1 = decrypt_ctr(ct1, b"my password")
    pt2 = decrypt_ctr(ct2, b"my password")
finally:
    # Always zeroize — use context manager or try/finally
    pass  # params already deleted above; use 'with params:' pattern instead
Recommended pattern — context manager
from cagoule.params import CagouleParams
from cagoule.cipher_ctr import encrypt_ctr

with CagouleParams.derive(b"my password") as params:
    ciphertexts = [
        encrypt_ctr(msg, b"my password", params=params)
        for msg in messages
    ]
# params.zeroize() called automatically on exit
C API — single message
#include "cagoule_api.h"

uint8_t out[plaintext_len + CAGOULE_API_OVERHEAD_AEAD];
size_t  out_len = sizeof(out);

int ret = cagoule_encrypt_v3(
    password, pwd_len,
    plaintext, pt_len,
    out, &out_len
);
if (ret != CAGOULE_API_OK) { /* handle error */ }
C API — bulk with amortized KDF
#include "cagoule_api.h"

// Derive once (~113ms for Argon2id)
CagouleKeyHandle *h = cagoule_derive_key(password, pwd_len, salt, salt_len);
if (!h) { /* handle error */ }

// Encrypt N messages — KDF cost paid once
for (int i = 0; i < N; i++) {
    uint8_t out[msg_len + CAGOULE_API_OVERHEAD_AEAD];
    size_t  out_len = sizeof(out);
    int ret = cagoule_encrypt_with_handle(h, msg[i], msg_len, out, &out_len);
    // ...
}

cagoule_key_handle_free(h);  // secure-zeroize + free
Streaming (large files)
#include "cagoule_stream.h"

CagouleStreamCtx *ctx = cagoule_stream_init(password, pwd_len, 65536, 0);
// 0 = v0x02 (default, with ChaCha20); 1 = allow v0x03 if env var set

while ((bytes_read = read(fd_in, buf, CHUNK_SIZE)) > 0) {
    uint8_t out[bytes_read + 16];  // chunk + Poly1305 tag
    size_t  out_len = sizeof(out);
    cagoule_stream_update(ctx, buf, bytes_read, out, &out_len);
    write(fd_out, out, out_len);
}

uint8_t final_out[256];
size_t  final_len = sizeof(final_out);
cagoule_stream_final(ctx, final_out, &final_len);
cagoule_stream_free(ctx);
Experimental mode (research only)
import os
os.environ["CAGOULE_EXPERIMENTAL_NO_AEAD"] = "1"

from cagoule.cipher_ctr_raw import encrypt_ctr_raw, decrypt_ctr_raw

# Requires both: env var AND explicit allow_experimental=True
ct = encrypt_ctr_raw(b"benchmark data", b"password", allow_experimental=True)
pt = decrypt_ctr_raw(ct, b"password", allow_experimental=True)
Do not use v0x03 for real data. Confidentiality depends solely on the algebraic layer, which has no published security proof.

Project Structure
CAGOULE/
├── cagoule/                        # Python package
│   ├── __init__.py                 # Public API — encrypt/decrypt/CagouleParams
│   ├── params.py                   # CagouleParams: KDF + key schedule
│   ├── cipher.py                   # CBC encrypt  (CGL1 v0x01)
│   ├── cipher_ctr.py               # CTR encrypt  (CGL1 v0x02) ← main path
│   ├── cipher_ctr_raw.py           # CTR experimental (CGL1 v0x03) ← v3.1.0 new
│   ├── decipher.py                 # CBC decrypt
│   ├── decipher_ctr.py             # CTR decrypt (v0x02 + v0x03)
│   ├── sbox.py                     # S-box (C backend + Python Feistel fallback)
│   ├── matrix.py                   # Vandermonde/Cauchy diffusion matrix
│   ├── omega.py                    # ζ(2n) round-key derivation
│   ├── fp2.py                      # Fp² arithmetic (mu generation)
│   ├── mu.py                       # μ parameter selection
│   ├── _binding.py                 # ctypes bindings to libcagoule.so
│   ├── _buffer_pool.py             # Thread-local buffer pool (re-entrancy safe)
│   ├── format.py                   # CGL1 wire format spec reference
│   └── c/                          # C backend
│       ├── Makefile
│       ├── src/
│       │   ├── cagoule_math.c          # Modular arithmetic (mulmod64, addmod64)
│       │   ├── cagoule_matrix.c        # 16×16 Vandermonde/Cauchy multiply
│       │   ├── cagoule_matrix_avx2.c   # AVX2 4-lane matrix (x86-64)
│       │   ├── cagoule_matrix_neon.c   # NEON 2-lane matrix (ARM) ← v3.1.0 new
│       │   ├── cagoule_sbox.c          # 2-round Feistel S-box + AVX2
│       │   ├── cagoule_sbox_avx2.c     # AVX2 S-box block operations
│       │   ├── cagoule_cipher.c        # CBC pipeline
│       │   ├── cagoule_ctr.c           # CTR pipeline (AVX2 4x unrolled)
│       │   ├── cagoule_omega.c         # ζ(2n) round-key derivation
│       │   ├── cagoule_kdf.c           # Argon2id + HKDF-SHA256 wrappers
│       │   ├── cagoule_params.c        # C-side parameter struct
│       │   ├── cagoule_api.c           # Unified C API ← v3.1.0 new
│       │   └── cagoule_stream.c        # Streaming per-chunk MAC ← v3.1.0 new
│       ├── include/                    # Public headers
│       │   ├── cagoule_api.h           # ← v3.1.0 new
│       │   ├── cagoule_stream.h        # ← v3.1.0 new
│       │   └── ...
│       ├── tests/                      # C test sources (468,857+ assertions)
│       │   ├── test_params_kat.c           # cagoule_params_derive KAT, cross-checked vs Python ← new
│       │   ├── test_error_paths.c          # cagoule_encrypt_v3/decrypt_v3, NULL-guard sweeps ← new
│       │   └── ...                         # (16 binaries total; see make tests)
│       └── fuzz/                       # libFuzzer harness
├── tests/                          # Python test suite (713 tests)
├── README.md
├── CHANGELOG.md
├── SECURITY.md
├── ARCHITECTURE.md
├── LICENSE
├── pyproject.toml
├── regenerate_kat.py
├── sbox_analysis_report.md        # S-box differential/linear analysis
└── sbox_analysis_report.json
Running Tests
# Full Python suite
python3 -m pytest tests/ -q

# C test suite
cd cagoule/c
make tests
for t in test_math test_matrix test_sbox test_cipher test_omega test_ctr test_format; do
    ./$t
done

# Fuzzing (requires clang)
clang -O1 -fsanitize=fuzzer,address,undefined \
    -Iinclude fuzz/fuzz_cipher.c -L. -lcagoule -o fuzz_cipher
./fuzz_cipher -max_len=65536 -runs=1000000

# KAT cross-backend verification
python3 regenerate_kat.py --check

# Cross-backend ζ(2n) verification (requires mpmath)
python3 -m pytest tests/test_omega.py -k BitExact -v
Wire Format (CGL1)
All CAGOULE ciphertexts are self-describing. The version byte determines the decryption pipeline — decrypt() dispatches automatically.

v0x01  CBC + ChaCha20-Poly1305 (legacy):
  CGL1 | 0x01 | SALT(32) | NONCE(12) | CT(n) | TAG(16)

v0x02  CTR + ChaCha20-Poly1305 (default):
  CGL1 | 0x02 | SALT(32) | NONCE(12) | CT(n) | TAG(16)
  Overhead: 65 bytes

v0x03  CTR + Poly1305 only (experimental, v3.1.0):
  CGL1 | 0x03 | SALT(32) | CT(n) | TAG(16)
  Overhead: 53 bytes
  AAD: MAGIC | VERSION | SALT (authenticated, not encrypted)
Compatibility notes:

v3.0.1 → v3.1.0: v0x02 ciphertexts are forward-compatible (IV formula unchanged from v3.0.1 final)
v3.0.0 → v3.0.1: v0x02 CTR ciphertexts are incompatible (IV formula changed in v3.0.1 Bug 2 fix)
v0x01 CBC ciphertexts are compatible across all versions
Security Status
Property	Status	Evidence
ChaCha20-Poly1305 AEAD	✅ Proven	Standard, 15+ years, IETF RFC 8439
Argon2id KDF	✅ Proven	PHC winner, IETF RFC 9106
HKDF-SHA256	✅ Proven	IETF RFC 5869
CTR IV uniqueness	✅ Fixed v3.0.1	Nonce-bound IV, empirically verified
Python S-box keyed	✅ Fixed v3.0.1	Bit-exact Feistel port, 16K comparisons
Algebraic degree	⚠️ Low (d=1, 2 rounds)	Known weakness — v3.2.0 fix planned
Algebraic IND-CPA	⚠️ Conjectured	DDT/LAT analysis, no formal proof
Formal security reduction	❌ Open problem	No reduction to standard assumption
Branch Number (MDS property)	⚠️ Mathematically implied, not yet independently computed for this project	See note below
The algebraic layer's most significant known weakness is the S-box: a 2-round Feistel network with a linear round function (x * rk mod p) has algebraic degree 1 — insufficient for strong confusion. The v3.2.0 roadmap replaces this with a high-round power map (f(x, rk) = (x+rk)^d mod p, 41 rounds for d=3) to achieve degree saturation d^r ≥ 2^64.

**Note on the Branch Number row, precisely stated:** an n×n Vandermonde matrix over a field, constructed from n distinct nodes, is a classical MDS matrix (a standard result from coding theory — this is the same property that makes Reed-Solomon codes MDS). CAGOULE's node-derivation step (`_derive_nodes` in `params.py` / `cagoule_params.c`) guarantees distinct nodes via collision-avoidance retries before matrix construction, and falls back to a Cauchy construction (also classically MDS) on the rare collision path. So the 16×16 diffusion matrix is MDS **by construction, following a well-known theorem** — not a novel or unverified claim about this specific project's math. For an MDS matrix with these dimensions, the branch number is n+1 = 17 by definition. What has **not** been done is an independent, project-specific computational verification producing this as a checked, documented output (no test file or script in this codebase currently computes or asserts this) — `SECURITY.md` and `ARCHITECTURE.md` still describe this as "not yet computed," which is accurate for "verified by this project's own tooling," even though the underlying mathematical property holds by construction. This README does not resolve that inconsistency between documents — flagging it here rather than silently picking a framing that contradicts the other security documentation.

See SECURITY.md for the complete threat model, known limitations, and the IND-CPA roadmap.

IND-CPA Roadmap (summary)
The path to a formal security argument for the algebraic layer:

Phase 1 — Classical cryptanalysis (current):

S-box redesign: f(x, rk) = (x+rk)^d mod p, r=41 rounds — planned v3.2.0
Algebraic degree saturation validation (symbolic, r=4,8,16,32,41)
DDT/LAT on the new S-box
Branch Number exact computation (MDS proof, target=17)
dudect constant-time re-verification
Phase 2 — Outside scrutiny:

ePrint preprint: "novel construction, preliminary analysis, IND-CPA conjectured"
At least one independent cryptanalysis pass
Phase 3 — Promotion of v0x03:

Formal security argument or reduction published
v0x03 becomes production default
CLI tool (v3.2.0) shipped for DevSecOps use
The honest current claim: IND-CPA conjectured, evidenced by preliminary differential/linear analysis. Not proven. Not ready for production without the ChaCha20-Poly1305 outer layer.

Comparison to Related Work
Cipher	Setting	ZK-friendly	Proof	Speed
AES-256	GF(2⁸)	❌ Expensive	✅ Formal (PRP under AES)	~4 GB/s (AES-NI)
ChaCha20	ARX, Z/2³² Z	❌ Expensive	✅ Formal (PRF)	~500 MB/s
MiMC	Z/pZ	✅ Native	⚠️ Conjecture	~10–50 MB/s
Poseidon	Z/pZ	✅ Native	⚠️ Conjecture	~10–50 MB/s
CAGOULE	Z/pZ	✅ Native	⚠️ Open	~50 MB/s (C), ~30 MB/s (Python e2e)
CAGOULE occupies the same algebraic setting as MiMC and Poseidon (prime-field power maps), with a different construction (Vandermonde diffusion + Feistel S-box + ζ(2n) round keys) and a stronger outer AEAD layer by default.

License
MIT — see LICENSE file.

Author
Slim Issa (LASS) — CTO, QuantOS Kairouan, Tunisia

Contributing
This is a research project. Before contributing:

Read SECURITY.md — especially the IND-CPA status section
Read ARCHITECTURE.md — algebraic construction details
Run the full test suite: pytest tests/ -q and make tests in cagoule/c/
Any change to the cryptographic core (matrix, S-box, omega, CTR pipeline) requires updating the KAT vectors: python3 regenerate_kat.py
Bug reports involving security findings: open a GitHub issue marked [SECURITY]. Do not include exploit code in public issues.
